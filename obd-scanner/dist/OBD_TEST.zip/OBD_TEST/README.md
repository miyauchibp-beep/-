# OBD スキャンツール（ELM327 / K-line 対応）

ELM327 互換アダプタで、車の故障コード・ライブデータを PC から読むためのツールです。
python-OBD を使わず、アダプタに直接 AT コマンドを送るので、**初期化の手順を細かく変えられます**。

## いまの課題と、まず試すこと

平成17年式アレックス（NZE121、K-line / KWP、プロトコル4）で、
PC からだと `BUS INIT: ...ERROR` になり ECU に繋がりません（スマホの Car Scanner では繋がる）。

`kline_init_test.py` は、初期化の設定を順番に試し、繋がった設定を `working_init.json` に保存します。

- 1 回目（`--round 1`）: 一般的な設定 10 通り。2026-10-12 の実車テストでは全滅。
  `BUS INIT: ...ERROR` で、共通規格の宛先 33 への 5baud 呼びかけに ECU が返事をしなかった
- 2 回目（既定）: 呼びかける宛先（`ATIIA`）を変えて 15 通り。国内独自の車は 01 00 に答えないことがあるので、
  初期化できたら 1A（ECU 情報）・21（メーカー独自データ）などの読み取り要求も試す。
  2026-10-12 の実車テスト（12.5V）では、15 通りすべて失敗
- 2026-10-12 トヨタ bB（QNC21, CAN）では自動判別で成功（プロトコル 6、対応PID 19 個）。
  PC → Bluetooth → アダプタ → ECU の経路は正常で、問題はアレックスの K-line 初期化に限られる
- 既定の組には、自動判別で CAN を見つけられない互換品向けに CAN 直接指定（ATSP6）も入れている。
  CAN だけを試すなら `--round 3`
- 2026-10-12 Car Scanner の画面: アレックスは **ISO 14230-4 KWP (5 baud init, 10.4 kbaud)**、較正ID 31205100
  （モード 09 に応答 = 共通規格に答える ECU）。宛先 33 で正しいはずで、違うのは初期化の始め方か電圧。
  `--round 4` はリセットを ATD / ATWS にしたり、ATSI で初期化を明示したりする（ATZ を一切送らない）。
  見つかったリセット方法は working_init.json の reset に保存され、obd_scan.py も同じ方法で接続する
- 2026-10-12 13:37 エンジン稼働・13.8V で `--round 1` も全滅 → 電圧が原因という仮説は外れ
- **解決の手がかり（Car Scanner の「ログのエクスポート」, 2026-10-02 のログ）**: 接続プロファイル
  「Toyota OBD-II / EOBD」は、標準の設定がすべて失敗したあと
  `ATSP4` → `ATSH8113F1` → `ATIB96` → `ATIIA13` → `0100` で `BUS INIT: ...OK 86 F1 13 41 00 BE 1F B8 10 70` を得ている。
  つまり **宛先 13・9600bps**（標準は宛先 33・10400bps）。接続後は 0904（較正 ID 31205100）に答え、0902（車台番号）は NO DATA。
  この組み合わせを既定の組の 3 番目と `--round 1` の 11 番目に追加した
- 次の手がかり: Car Scanner が実際に送っている設定（接続プロファイル・通信ログ）と、
  新しい CAN の車で PC → アダプタ → ECU の経路が正常か（`--round 1 --only 10`）

### 手順（Windows）

1. このフォルダ（`kline_init_test.py` と `obd_scanner` フォルダ）を `C:\Users\Owner\Downloads\OBD` に置く
2. スマホの Bluetooth をオフにし、Car Scanner を閉じる
3. 車のキーを ON（エンジンは OFF、電圧が低ければ安定化電源をつなぐ）
4. `run_kline_test.bat` をダブルクリック（COM ポートを聞かれます。前回の番号を覚えています。終わっても画面は閉じません）。
   または、コマンドプロンプトで:

   ```
   cd C:\Users\Owner\Downloads\OBD
   python kline_init_test.py COM7
   ```

5. 終わったら `kline_logs\kline_test_日時.txt`（と、成功していれば `working_init.json`）を Claude に渡す

- 全部で数分かかります（設定の切り替えごとに 5 秒待ちます。K-line は続けて初期化すると失敗しやすいため）
- 成功しても全部試したいとき: `python kline_init_test.py COM7 --all`
- 特定の番号だけ: `python kline_init_test.py COM7 --only 2 3`
- アダプタなしで動きを見る: `python kline_init_test.py --demo`

### COM ポートについて

アダプタの番号は、Windows の「その他の Bluetooth 設定」→「COM ポート」タブで「OBDII」の **発信** の行。
ペアリングし直すと変わる（2026-10-12 の再起動後に COM6 → COM7 に入れ替わり、COM6 は着信になった）。
.bat から起動すると番号を聞かれ、つながった番号は `obd_port.txt` に保存されて次回の既定値になる。
着信側のポートや、相手が使用中のポートを開くと `PermissionError(13)`（アクセスが拒否されました）になる。

**このアダプタはスマホ（Car Scanner）と繋ぐと、PC とのペアリングが使えなくなる**（前回・今回とも同じ）。
そのとき COM を開くと `OSError(22, 'セマフォがタイムアウトしました。', None, 121)`。
直し方: スマホで OBDII を登録解除 → Windows で OBDII を削除 → アダプタ OFF→ON → Windows で再ペアリング
（PIN 1234 / 0000）→「COM ポート」タブで新しい「発信」の番号を確認。

### 安全のための決まり

- 車に送るのは**読み取りの要求（01 / 03 / 1A / 21）だけ**です。故障コードの消去や書き込みはしません
- スナップオン診断機（NANO-BT2）の **COM4 / COM5 は指定しても拒否**します

## 故障コード・ライブデータの読み取りと AI 診断（obd_scan.py）

`run_scan.bat` をダブルクリック、または `python obd_scan.py COM7`。
車台番号・警告灯・レディネス・故障コード（現在／保留中／消去不可）・フリーズフレーム・ライブデータを読み、
`scan_logs\scan_日時.json` に保存します。

続けて車両情報と症状を聞き、Claude（`claude-opus-5-5`）に原因候補（可能性順）・確認手順・修理方法を出させて
`scan_logs\diag_日時.md` に保存します。

- API キーは環境変数 `ANTHROPIC_API_KEY`（Windows: `setx ANTHROPIC_API_KEY "sk-ant-..."` のあと画面を開き直す）
- 安全上の判定で断られたときは、サーバー側で別モデルに自動で切り替える設定（`fallbacks: "default"`）にしています
- 診断しない: `--no-ai` ／ 保存済みの結果で診断し直す: `--from-scan scan_logs\scan_日時.json`

- エンジンがかかっていれば、続けて 10 秒間 O2 センサ・燃料補正・回転数を読み、最小／最大／平均と
  フロント O2 の反転回数（0.45V をまたいだ回数）を `trend` として保存・診断に使う（`--trend 秒`、0 で無効）。
  フロント O2 はほかの項目の合間に毎回はさんで読み、間隔を短くしている
- 車とのやり取りはすべて `scan_logs\raw_日時.txt` に記録する（読み取れない項目があったときの調査用）
- 2026-10-12 13:53 アレックスで初めて読み取り成功（前回の設定 = トヨタ K-line で接続、較正 ID 31205100、DTC 0 件）。
  PID 01 が表示されなかった原因は raw ログで判明: アレックスは `41 01 00` と **1 バイトしか返さない**（MIL 消灯・DTC 0 件、
  レディネスなし）。1 バイトでも MIL と DTC 数を読むよう修正。リア O2（PID 15）は ECU が `00 FF` = 0.000V と返しており、
  読み違いではない（装着の有無は PID 13 で確認する）。この raw ログは tests/data に入れ、再生テストに使っている
- ライブデータを表示し続ける: `python obd_scan.py COM7 --live`（`--csv` で記録も）。
  `--pids o2`（O2 センサ 2 つと回転数）や `--pids 15` で項目を絞ると、待ち時間なしで速く更新する
- 2026-10-12 14:05 アレックス: PID 13 = B1S1、B1S2（リア O2 は装着）なのに PID 15 は 0.000V 固定 → 実車のリア O2 系統の点検が必要
- 接続は「前回つながった設定（working_init.json）→ 自動判別 → CAN 11bit 500k → トヨタ K-line（宛先 13・9600bps）」の順に
  繋がるまで試し、繋がった設定を working_init.json に保存する（bB の設定が残ったままアレックスにつないでも切り替わる）

## 構成

| ファイル | 内容 |
| --- | --- |
| `obd_scan.py` | 故障コード・フリーズフレーム・ライブデータの読み取りと保存 |
| `kline_init_test.py` | K-line 初期化設定の自動テスト |
| `obd_scanner/elm327.py` | アダプタとの通信、応答の解析（K-line / CAN 両対応） |
| `obd_scanner/pids.py` | ライブデータ（回転数・水温など）の換算、レディネス |
| `obd_scanner/dtc.py` | 故障コードの読み取りと日本語説明 |
| `obd_scanner/scan.py` | 一通りの読み取り（モード 01/02/03/07/09/0A） |
| `obd_scanner/ai_diag.py` | Claude API による診断（原因候補・確認手順・修理方法） |
| `obd_scanner/console.py` | COM4/5 の拒否、終了前に画面を止める処理 |
| `obd_scanner/simulator.py` | 動作確認用の疑似アダプタ |
| `tests/` | テスト（`python -m unittest discover -s tests`） |

繋がる設定がわかったら、`Elm327(...).connect(protocol="4", extra_init=["ATKW0"])` のように
その設定で接続でき、`obd_ai_diag.py` の通信部分をこれに置き換える予定です。
