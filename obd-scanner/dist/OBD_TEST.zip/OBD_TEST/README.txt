﻿OBD スキャンツール

準備
  スマホの Bluetooth をオフ、Car Scanner を閉じる。
  車にアダプタをさして、キーを ON（エンジンは OFF のままでよい）。
  （青い「PC が保護されました」が出たら「詳細情報」→「実行」）
  起動すると COM ポートを聞かれます。Windows の「その他の Bluetooth 設定」→「COM ポート」で
  「OBDII」の「発信」になっている番号（2026-10-12 時点では COM7）。一度つながると次回から覚えています。

■ run_scan.bat … 故障コード・フリーズフレーム・ライブデータを読み、Claude が診断
  読み取り後に「車両」「症状」を聞かれるので入力（空のまま Enter でも可）。
  結果は scan_logs フォルダに保存されます（scan_日時.json、診断は diag_日時.md）。
  Claude の診断には API キーが必要です。未設定なら、コマンドプロンプトで一度だけ
    setx ANTHROPIC_API_KEY "sk-ant-で始まるキー"
  を実行し、画面を開き直してください。

■ run_diag_last.bat … 車をつながずに、いちばん新しい読み取り結果を Claude に診断させる
  ライブデータを見続けたいときは、このフォルダのアドレス欄に cmd と入れて Enter し、
    python obd_scan.py COM7 --live
  （CSV にも記録するなら --live --csv。Ctrl+C で終了）

■ run_kline_test.bat … 繋がらない車で、接続設定を探す
  繋がった設定は working_init.json に保存され、run_scan.bat が自動で使います。

いずれも最後に「Enter キーを押すと閉じます」と出たら、
画面の文字を全部コピーして Claude に貼ってください。

車に送るのは読み取りだけです。故障コードの消去などはしません。
COM4 / COM5（スナップオン）は使いません。
